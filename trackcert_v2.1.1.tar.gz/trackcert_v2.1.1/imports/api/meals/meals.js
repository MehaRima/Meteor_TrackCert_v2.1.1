// import { Mongo } from 'meteor/mongo';

// export const Meals = new Mongo.Collection('meals');

// // export default Meals;
