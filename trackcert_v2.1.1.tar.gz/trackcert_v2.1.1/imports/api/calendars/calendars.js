// import { Mongo } from 'meteor/mongo';

// export const Calendars = new Mongo.Collection('calendars');

// // export default Calendars;
