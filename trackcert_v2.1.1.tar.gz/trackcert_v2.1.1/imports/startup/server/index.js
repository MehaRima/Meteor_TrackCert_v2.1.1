// import { Mongo } from 'meteor/mongo';
// import { Meteor } from 'meteor/meteor';
// import { Meals } from '../../api/meals/meals.js';
// import { Calendars } from '../../api/calendars/calendars.js';

// console.log('server st arup code ran');
// console.log('server ' + Meals);
// console.log(Meals.findOne({}));
