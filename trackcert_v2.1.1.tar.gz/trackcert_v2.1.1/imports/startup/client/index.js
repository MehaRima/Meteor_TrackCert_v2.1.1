// import { Meteor } from 'meteor/meteor';
import './routes.js';
// import { Mongo } from 'meteor/mongo';
// import { Meals } from '../../api/meals/meals.js';
// import { Calendars } from '../../api/calendars/calendars.js';

// console.log(Meals);
// console.log(Meals.findOne({}));
